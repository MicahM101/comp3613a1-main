# Phase 4 — Wireframe review

- Date: 2026-10-11
- Tool: OpenCode
- Phase: 4 (wireframes in `docs/wireframes/`)

## Student

> Use the student-build skill. Phase 4. Wireframe images are in docs/wireframes/

> Whoops try again, it should be added now.

*(provided three wireframe images: `Workflow 1 - Submit Hours.png`, `Workflow 2 - Verify Hours.png`, `Workflow 3 - Redeem Progress.png`)*

Answers to the five Phase 4 questions:

> 1. The user should land at the beginning wireframe of the respective workflow.
> 2. Yes, it does have a confirmation dialogue.
> 3. The Admin should see student's total hours earned.
> 4. Yes, it should only ask for more information when necessary but all selections should require confirmation.
> 5. They should be their own small Charity table.
>
> Implement all suggestions except the third one. The volunteer_cause.hoursAvailable can be used for a cause information page later.

## Guide

Session start: confirmed **student-build** (3 skips, one phase per chat, next phase in a new chat). Read `docs/report.md` — Phases 1–3 artefacts present (project, `Feature (user)` lines, use-case PNG, first-draft `erDiagram`).

First check: `docs/wireframes/` empty (folder missing) — named the 8 use cases needing images and waited. No substitute drawn.

After images arrived, checked each use case against the set — all 8 covered, set readable → no redesign.

Model edit suggestions (`entity.property — seen on <image>`):

1. `submission.start_time` — Workflow 1 (form field 3) + Workflow 2 (`Start Time:`)
2. `submission.document_path` — Workflow 1 (upload) + Workflow 2 (`Participation_Form_Signed.pdf`)
3. `student.first_name`, `student.last_name` — Workflow 2 (profile card)
4. `volunteer_cause.description` — Workflow 1 (cause card body)
5. `hours_redemption.charity` — Workflow 3 (Partner Charity dropdown)

Mismatch note: `volunteer_cause.hoursAvailable` / `dateAvailable` unused by any image.

No model change needed: computed hours totals, "Max: 50 hours" service rule, Workflow 2 search filters.

Questions (5/5, base confidence 0.88):

1. Where does the user land after Confirm / Approve?
2. Does Reject confirm the same way as Approve?
3. Phase 2 said Admin views all hours — does the admin need a student's total earned hours?
4. Non-charity rewards: does Select go straight to the confirmation dialog?
5. Which suggestions to apply; charities as a table or a stored string?

Applied per student answers: suggestions 1, 2, 4, 5 accepted (#5 as a `CHARITY` table + nullable FK); #3 declined — single `Student.name` kept. `hoursAvailable` / `dateAvailable` kept for a future cause information page. Phase 4 revisions + workflow clarifications written into `docs/report.md`; three wireframes embedded under `## Wireframes` with 8 `student-build:wireframe-coverage` blocks.

```text
Phase 4 done
Artefact: docs/report.md (+ docs/wireframes/*.png)
Base confidence: 0.88
Questions: 5/5
Suspicion: none
Skips: 0/3 used
Report: updated
```

Handed the Phase 5 prompt (theming preferences) for a new chat.
