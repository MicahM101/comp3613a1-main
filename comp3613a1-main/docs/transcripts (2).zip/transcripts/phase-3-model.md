# Phase 3 — model diagram (ERD)

- Date: 2026-10-05
- Tool: OpenCode
- Phase: 3 (one design chat per phase)

## Student

Use the student-build skill. Phase 3. Here are my entities and properties. Draft the model diagram from docs/report.md.

Student
- studentId
- totalHours
- name

Admin
- adminId
- name
- email

Submission
- submissionId
- student
- hoursCompleted
- cause
- date

(ignore the previous cancelled prompt, I was not done, use this one instead)

Student
- studentId
- totalHours
- name
- email

Admin
- adminId
- name
- email

Submission
- submissionId
- student
- hoursCompleted
- cause
- dateCompleted

Volunteer Cause
- causeId
- causeName
- hoursAvailable
- dateAvailable

Reward
- rewardId
- rewardName
- hourCost

One to many, one student has many submissions. Also, submission should hold foreign keys for Student and cause.

It would be one admin verifies many submissions and one submission can only be verified by one or no admin. The foreign key is on submission.

Yes this would be a many to many, and I want a bridge table called HoursRedemption. The layout as follows.
Hours Redemption
- studentId(PK1, FK1)
- rewardId(PK2, FK2)
- dateRedeemed
- hoursSpent

Yes, it should have a lifecycle attribute called state. This will have a value denoting the state of the submission, whether it is pending, verified or rejected.

It should be computed

## Guide

Confirmed student-build skill, Phase 3. Read `docs/report.md` (Phase 1: Student Awards, workflows SubmitHours/VerifyHours/RedeemProgress; Phase 2 use-case diagram embedded).

Asked (one at a time, within cap):

1. Which entities does the model need? (initial list was incomplete) → student supplied Student, Admin, Submission, Volunteer Cause, Reward.
2. How are Student and Submission related, and which entity holds the FK? → one-to-many; Submission holds FKs to Student and Volunteer Cause.
3. How does Admin relate to Submission? → one-to-many (adminId FK on Submission, nullable — a submission may be verified by no admin yet).
4. How are Student and Reward related for RedeemProgress? Many-to-many? Bridge with extra columns? → many-to-many with bridge `HoursRedemption` (composite PK studentId+rewardId, dateRedeemed, hoursSpent).
5. How is Admin verification recorded? → `Submission.state` lifecycle: pending / verified / rejected.
6. Is Student.totalHours stored or computed? → computed.

Wrote the Mermaid `erDiagram` into `docs/report.md` (Model diagram section) from the student's entities, properties, and answers, with notes: Submission FKs to Student/Admin/Volunteer Cause; state lifecycle; HoursRedemption bridge; totalHours computed (verified hours − hoursSpent); assumed many submissions per Volunteer Cause.

Pause block:

```text
Phase 3 done
Artefact: docs/report.md (Mermaid erDiagram in "Model diagram")
Base confidence: 0.75
Questions: 5/5
Suspicion: none
Skips: 0/3 used
Report: updated
```
