# Guide chat — OpenCode — Phases 5–6 (build, polish, deploy)

**Tool:** OpenCode (this session)
**Student:** Micah Mitchell (816046428)
**Scope:** COMP 3613 Assignment 1, Phase 5 (theme → build → polish) and Phase 6 (Render deploy) for the **Student Awards** project.

> **Note on coverage:** this is the *implement/polish* chat. Phases 1–4 (project and workflow selection, include/extend, entities and relationships, use-case diagram, wireframes) ran in earlier Guide chats that are not reachable from this session. Their decisions are recorded in `docs/report.md`, which was co-written from those turns. Student utterances below are verbatim; Guide turns are abridged summaries of what was done, marked where abridged.

---

## Starting position

Phase 5 theming had been applied (CSS tokens, graduation-cap lockup, Montserrat, landing/login/register, authenticated shell). Workflow 1 (SubmitHours) was already built and verified by the student. Workflow 2 (VerifyHours) was scaffolded with two marked student snippets.

**Student logins in play:** `bob/bobpass`, `carol/carolpass`, `admin/adminpass`.

---

## Turn 1 — a new requirement, and the Workflow 3 choice

**Student:**
> "Ive thought of something else. The available hours for a cause should go down for every time a student has their hours confirmed on a cause. Let the admin have a cause page where they can add more hours to the cause page. With regards to Workflow 3 question, do A, make it so the student can't start the reward process if they can't afford it."

**Guide (abridged):** Implemented cause availability end to end — `VolunteerCauseRepository.adjust_hours`, a decrement inside `ReviewService.decide` on approval, a new `CauseService`, an admin Causes page at `/admin/causes` with an inline "Add hours" form, and a Causes tab for the admin. Then scaffolded Workflow 3: `Reward`/`Charity`/`HoursRedemption` models, repositories, `RedeemService`, the `/rewards` grid, charity screen and confirmation screen, and seeded the wireframe's 8 rewards and 4 charities. Asked one question about what should happen when a cause runs out.

---

## Turn 2 — blocking approvals, and a data miss

**Student:**
> "Block the approval until someone tops up the hours. Also the new causes weren't added. Fix this and then I will do the snippet for workflow 3."

**Guide (abridged):** Replaced the earlier "floor at 0" default with the student's rule — `ReviewService.decide` now raises before anything is written when the cause lacks hours, the admin is flashed the shortfall, and the review card shows the cause balance with a "not enough — approve will be refused" badge. Diagnosed the missing causes as a data problem, not a bug: the running database had never been re-seeded since the five new causes were added. Ran `python manage.py seed`, which reported `causes 5, rewards 8, charities 4`.

---

## Turn 3 — Workflow 3 snippets, and repeat redemptions

**Student:**
> "The snippets are done. And yes, I want repeat redemptions available."

**Guide (abridged):** Reviewed both snippets. The model snippet (`charity_id`, `date_redeemed` with a default factory, `hours_spent`) passed. The route snippet was thin but fell off the end on success — no flash, no redirect — so a successful redemption returned `None`. Flagged it and left the correction to the student. Applied the repeat-redemptions choice: `HoursRedemption` gained a surrogate `id` PK, the composite lookup was removed, and the "already redeemed" refusal was dropped. ERD updated.

---

## Turn 4 — the student's correction

**Student:**
> "How are the snippets now? I change it to add the success path and flash. Sorry about that. After you confir, I will init and run"

**Guide (abridged):** Confirmed the correction (`flash("Redemption successful!")` + redirect), removed the now-stale `TODO(student)` marker from the docstring, and recorded a `passed: yes` code-check block alongside the earlier partial one. Everything compiled and all 33 routes imported.

---

## Turn 5 — polish round 3

**Student:**
> "Everything works great. I just have some changes to polish.
> - Yung Bredda spelt wrong
> - Add more rewards interesting student rewards
> - Make rewards and charity tiles look more exciting
> - Make the select button light up when being hovered over
> - Change the Student account badge at the top right to the Welcome {Student's name}
> - Add a search bar for causes and rewards"

**Guide (abridged):** All six applied. Corrected the seeder spelling to *Yung Bredda Concert Ticket* (noting `seed` is additive and would have left the old row, so `init` was needed). Rewards grew 8 → 14. Reward cards restyled as `.reward-tile` (gradient top rule, gold-ringed icon medallion, gold cost line, hover lift); the charity dropdown became four `.charity-tile` cards that fill gold when chosen — the form still posts `charity_id`, so the student's route snippet needed no change. `.btn-select` fills gold with a glow on hover/focus. Top bar now reads **Welcome, bob** for students; admins keep the wireframe's grey *Admin Account*. Search bars added to Causes and Rewards, filtered in the repositories (`ilike`) and passed through the services — routes only bind `q`.

---

## Turn 6 — where next

**Student:**
> "Everything works well, what is next."

*(chose: "Final walkthrough, then deploy")*

**Guide (abridged):** Confirmed Phase 5 was complete — theme, three workflows with two student snippets each, three polish rounds. Gave a full end-to-end walkthrough script covering all three workflows chained together, plus the approval-block path.

---

## Turn 7 — final change

**Student:**
> "Ok, everythin works except for one thing I want to change. Make it so that if a student tries to submit more hours that is available, it doesn't let them similar to how the page reacts when a required field is missing, just in case, let them know more their hours are exceeding the total hours available for the cause. This is my final change."

*(transcribed as: "…just in this case, let them know [that] their hours are exceeding the total hours available for the cause.")*

**Guide (abridged):** Implemented both halves. Client side: the selected cause's balance becomes the hours input's `max`, a hint reads "N hours available for \<cause\>", and going over sets custom validity — so the browser blocks the POST with the same native red bubble an empty required field gets, reading *"Your hours exceed the total available for this cause — Save the Turtles! has 35 hours."* Server side: `SubmissionService.check_hours_fit` owns the rule, `record_submission` calls it first, and the preview route runs it before the confirmation screen. Also removed a stray `service.causes.get_by_id` from the router — the service returns the cause now.

---

## Turn 8 — Phase 6 prep

**Student:**
> "Ok, restarted. Lets continue."

**Guide (abridged):** Checked for the Render MCP — no servers exposed. Found a genuine first-deploy blocker: `db_pool_size: 10` + `db_additional_overflow: 10` = up to 20 connections against Render's free Postgres limit of **5**. Added `DB_POOL_SIZE=2` / `DB_ADDITIONAL_OVERFLOW=1` to `render.yaml`. Then found the code was uncommitted — the last commit was *"VerifyHours workflow (2) completed"*, so Render would have deployed pre-Workflow-3 code. Asked who should push.

---

## Turn 9 — git

**Student:**
> "Commited and pushed."

**Guide (abridged):** Verified `bc1da0f Workflow RedeemHours (3) completed` was on `origin/main` with the local branch in sync. W out the full dashboard deploy steps from `render.yaml`.

---

## Turn 10 — dashboard navigation

**Student:**
> "Wait, so where do I go now to create the database"

**Guide:** Gave the path — dashboard.render.com → New + → PostgreSQL, with the exact field values.

---

## Turn 11 — the build failure

**Student:**
> "What do I do with the internal URL? Its saying that no such requirements.txt exists"

**Guide (abridged):** Answered both. The Internal URL becomes the `DATABASE_URI` env var, pasted unmodified — `sqlalchemy_uri()` rewrites Render's `postgres://` prefix. Diagnosed the build error: `git rev-parse --show-toplevel` showed the repo root is the **outer** folder, containing a single `comp3613a1-main/` subdirectory (an artifact of unzipping before `git init`), so the project's `requirements.txt` is one level below GitHub's root. Offered the instant fix (Render **Root Directory** = `comp3613a1-main`) or flattening the repo properly.

---

## Turn 12 — deployed

**Student:**
> "No, it works and it is now running in render. What are the steps now?"

**Guide:** Gave the three remaining steps — verify the live app, send the URL for the report, then judge + PDF export.

---

## Turn 13 — closing out

**Student:**
> "The public url is: https://faststarter-sbp0.onrender.com/
> I am ready to end phase 6"

**Student:**
> "My name is Micah Mitchell and my student ID number: 816046428"

**Guide:** Recorded the Phase 6 section in `docs/report.md`, wrote this transcript, ran student-judge, and exported the PDF.
