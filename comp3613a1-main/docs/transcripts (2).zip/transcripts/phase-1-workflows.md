# Phase 1 — Select the project and name the workflows

- Date: 2026-10-03
- Tool: OpenCode
- Phase: 1 (design chat, one phase)

## Student

Start the assignment using the build skill

The students awards

SubmitHours (Student)
VerifyHours (Admin)
RedeemProgress (Student)

Upload the phase 1 transcript from this chat

## Guide

**Confirmed student-build.** Stated the session rules: one design chat per phase (the next *phase* opens in a new chat), 3 skips available, no app code before Phase 5, `docs/report.md` and `docs/wireframes/` checked to see which phase this is — the report was still the placeholder, so Phase 1.

**Question 1 — project selection:** Which of the six briefs is your assigned project (per the myeLearning spreadsheet)?

1. Alumni App
2. Internship Platform
3. MyAdvisor
4. Research Platform
5. Student Awards
6. Student Accommodation

**Student answer:** The students awards.

**Question 2 — workflows:** Name at least three workflows, format `Feature (user)`, one per line; screen steps belong in the Phase 4 wireframes.

**Student answer:**

```text
SubmitHours (Student)
VerifyHours (Admin)
RedeemProgress (Student)
```

Three workflows given in the required format; exit gate met. Wrote `docs/report.md` — Assigned project: **Student Awards (incentive system)**; Three workflows: SubmitHours (Student), VerifyHours (Admin), RedeemProgress (Student).

**Pause block:**

```text
Phase 1 done
Artefact: docs/report.md (Assigned project, Three workflows)
Base confidence: 1.00
Questions: 2/2 (no cap needed — project + workflows given)
Suspicion: none
Skips: 0/3 used
Report: updated
```

Handed the Phase 2 prompt for a new chat:

```text
Use the student-build skill. Phase 2. Here is my Phase 1 artefact in docs/report.md. Draft the use-case diagram from it.
```
