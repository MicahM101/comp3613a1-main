# Phase 2 — use-case diagram

- Date: 2026-10-04
- Tool: OpenCode
- Phase: 2 (one design chat per phase)

## Student

> Use the student-build skill. Phase 2. Here is my Phase 1 artefact in docs/report.md. Draft the use-case diagram from it.

> VerifyHours should <<include>> checking submitted hours and should be extended by checking supporting documents
> Submit documents should be extended by submit supporting documents
> Redeem progress should <<include>> choosing reward

> Yes

> Checking a students hours, as a student should be able to check their own hours and an admin should be able to check all hourse

> This happens with no admin step as it is the student's choice what they do with their hours

> They can check it separately, meaning that this can be a separate use case as well, "viewing hours earned"

## Guide

Read `docs/report.md` (Phase 1 artefact): project **Student Awards (incentive system)**; workflows `SubmitHours (Student)`, `VerifyHours (Admin)`, `RedeemProgress (Student)`.

Steering questions (cap 5, base confidence 0.80):

1. Which of these use cases should «include» or «extend» another, rather than being a separate actor association?
   → VerifyHours «includes» Check Submitted Hours, extended by Check Supporting Documents; SubmitHours extended by Submit Supporting Documents; RedeemProgress «includes» Choose Reward.

2. Clarification: "Submit documents" meant the SubmitHours workflow from Phase 1 extended by "Submit Supporting Documents"?
   → Yes.

3. Are any use cases shared by more than one actor?
   → Checking a student's hours: Student checks own, Admin checks all.

4. Edge case: after RedeemProgress, how does the reward get approved/fulfilled — an Admin use case, or no admin step?
   → No admin step; it is the student's choice what they do with their hours. Noted as a deliberate design decision.

5. Does the Student need a separate way to view their balance/available rewards before redeeming?
   → Yes, a separate use case: "View Hours Earned".

Draft written from their answers:

- Created `docs/diagrams/use-case.json`, ran `python manage.py usecase` → `docs/diagrams/use-case.png`.
- Actors: Student (left), Admin (right).
- Embedded `![Use case diagram](diagrams/use-case.png)` in `docs/report.md` with notes (includes/extends, shared View Hours Earned, no-admin-approval assumption).
- Confirmed the PNG exists and the relative markdown link resolves.

Pause block:

```text
Phase 2 done
Artefact: docs/report.md (+ docs/diagrams/use-case.json, docs/diagrams/use-case.png)
Base confidence: 0.80
Questions: 5/5
Suspicion: none
Skips: 0/3 used
Report: updated
```

Told the student to open a **new chat** for Phase 3.
