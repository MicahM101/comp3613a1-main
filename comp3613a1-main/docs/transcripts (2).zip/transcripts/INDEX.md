# Session transcripts

Filled by the **Guide agent** (Copilot Agent, Cursor, or OpenCode) when
building the report — one markdown file per Guide chat for this project.
`python manage.py report` only packages these files; it does not scrape an IDE.

Chats packaged: **5**

| Chat | File |
| --- | --- |
| `phase-1-workflows` | [phase-1-workflows.md](phase-1-workflows.md) |
| `phase-2-use-case` | [phase-2-use-case.md](phase-2-use-case.md) |
| `phase-3-model` | [phase-3-model.md](phase-3-model.md) |
| `phase-4-wireframes` | [phase-4-wireframes.md](phase-4-wireframes.md) |
| `opencode-phase5-6-build-polish-deploy` | [opencode-phase5-6-build-polish-deploy.md](opencode-phase5-6-build-polish-deploy.md) |
