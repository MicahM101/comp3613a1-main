# Session transcripts — format

The Guide agent writes **one markdown file per Guide chat** for this project into
this folder. `python manage.py report` packages them (INDEX + `docs/transcripts.zip`
+ PDF appendix). It does **not** scrape any IDE.

Naming: `phase-<n>-<slug>.md`, e.g. `phase-1-workflows.md`,
`phase-4-wireframes.md`, `phase-5-implement.md`, `phase-6-deploy.md`.

Each file:

```markdown
# Phase <n> — <short title>

- Date: <YYYY-MM-DD>
- Tool: <OpenCode | Copilot Agent | Cursor>
- Phase: <n> (one design chat per phase; Phase 5 may cover theming + all workflows)

## Student

<verbatim student turns>

## Guide

<assistant turns — condensed is fine; keep questions, decisions, pause blocks>
```

Include student and assistant turns; **prefer student utterances** (verbatim).
Do not invent chats. `INDEX.md` and this file are skipped when packaging.
